import { Component, OnInit } from '@angular/core';
 
declare var jQuery: any;
 
@Component({
  selector: 'home-page',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  constructor(
 
  ) {
  

  }
 

 

  ngOnInit() { 
  }
}
