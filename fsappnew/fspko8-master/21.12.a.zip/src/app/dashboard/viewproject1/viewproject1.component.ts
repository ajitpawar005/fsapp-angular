import {Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewproject1',
  templateUrl: './viewproject1.component.html',
  styleUrls: ['./viewproject1.component.scss']
})
export class Viewproject1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
