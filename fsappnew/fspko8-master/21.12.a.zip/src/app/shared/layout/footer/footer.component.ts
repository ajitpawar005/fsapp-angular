import { NO_ERRORS_SCHEMA, Component } from '@angular/core';

@Component({
    selector: 'fs-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss']
})
export class FooterComponent {}
