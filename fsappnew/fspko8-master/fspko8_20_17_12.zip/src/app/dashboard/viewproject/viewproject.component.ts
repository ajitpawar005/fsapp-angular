import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewproject',
  templateUrl: './viewproject.component.html',
  styleUrls: ['./viewproject.component.scss']
})

export class ViewprojectComponent implements OnInit {
  constructor() { }
  ngOnInit() {
    console.log("Viewproject component");
  }
}
