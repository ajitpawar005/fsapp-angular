// export class Profile {
//   username: string;
//   bio: string;
//   image: string;
//   following: boolean;
// }

export class Profile {
  user:{
    firstName: string;
    lastName: string;
  }
  bio: string;
  image: string;
  following: boolean;
}