export class Language { 
    constructor(public en:string, public fr:string,
        public es:string) {
    }
}
 