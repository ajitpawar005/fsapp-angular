import { Component, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
    selector: 'fs-sendmail',
    templateUrl:'./sendmail.component.html',
    styleUrls:['./sendmail.component.scss']
})

export class SendmailComponent implements OnInit {
    ngOnInit(){
        
    }
}