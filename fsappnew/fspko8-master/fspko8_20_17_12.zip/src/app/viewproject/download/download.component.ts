import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { EventListener } from '@angular/core/src/debug/debug_node';

@Component({
    selector: 'fs-download',
    templateUrl:'./download.component.html',
    styleUrls:['./download.component.scss']
})

export class DownloadComponent implements OnInit {
    ngOnInit(){
        
    }
}