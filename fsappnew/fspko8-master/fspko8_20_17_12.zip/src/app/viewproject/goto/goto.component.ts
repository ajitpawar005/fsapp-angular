import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { EventListener } from '@angular/core/src/debug/debug_node';

@Component({
    selector: 'fs-goto',
    templateUrl:'./goto.component.html',
    styleUrls:['./goto.component.scss']
})

export class GotoComponent implements OnInit {
    ngOnInit(){
        
    }
}