export class User {
  status: string;
  message : string;
  id_token : string;
  user:{
    firstName: string;
    lastName: string;
  }
}