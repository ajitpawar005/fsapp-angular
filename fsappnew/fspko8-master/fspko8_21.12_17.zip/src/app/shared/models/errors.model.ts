export class Errors {
  status:boolean;
  message: string;
}
