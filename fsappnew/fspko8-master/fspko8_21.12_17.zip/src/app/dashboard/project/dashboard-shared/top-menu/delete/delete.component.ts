import { Component, OnInit, Output } from '@angular/core';

@Component({
    selector: 'fs-deleteasset',
    templateUrl:'./delete.component.html',
    styleUrls:['./delete.component.scss']
})

export class DeleteComponent implements OnInit {
    ngOnInit(){
        
    }
}