import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-subproject',
  templateUrl: './test-subproject.component.html',
  styleUrls: ['./test-subproject.component.css']
})
export class TestSubprojectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
