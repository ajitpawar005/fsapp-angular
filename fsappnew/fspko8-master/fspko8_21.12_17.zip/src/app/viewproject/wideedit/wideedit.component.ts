import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { EventListener } from '@angular/core/src/debug/debug_node';

@Component({
    selector: 'fs-wideedit',
    templateUrl:'./wideedit.component.html',
    styleUrls:['./wideedit.component.scss']
})

export class WideEditComponent implements OnInit {
    ngOnInit(){
        
    }
}