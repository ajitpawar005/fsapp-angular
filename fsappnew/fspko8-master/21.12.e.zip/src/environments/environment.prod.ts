export const environment = {
  production: true,
  // api_url: 'https://conduit.productionready.io/api'
  api_url : "http://fsapi.sarvaya.com/api/"
};
