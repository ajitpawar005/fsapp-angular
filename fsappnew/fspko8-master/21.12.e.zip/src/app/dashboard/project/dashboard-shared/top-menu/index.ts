export * from './goto/goto.component';
export * from './sendmail/sendmail.component';
export * from './download/download.component';
export * from './printtool/printtool.component';
export * from './viewsettings/viewsettings.component';