import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'sidebar-menus',
  templateUrl: './sidebarmenus.component.html',
  styleUrls: ['./sidebarmenus.component.scss']
})
export class SidebarmenusComponent implements OnInit {
  ngOnInit() {
  }
}