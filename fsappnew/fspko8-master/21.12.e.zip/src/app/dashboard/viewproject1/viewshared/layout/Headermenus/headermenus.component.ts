import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'header-menus',
  templateUrl: './headermenus.component.html',
  styleUrls: ['./headermenus.component.scss']
})
export class HeadermenusComponent implements OnInit {
  ngOnInit() {
  }
}