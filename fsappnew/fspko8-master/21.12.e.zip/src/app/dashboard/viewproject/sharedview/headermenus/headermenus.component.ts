import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'viewproject-headermenus',
  templateUrl: './headermenus.component.html',
  styleUrls: ['./headermenus.component.scss']
})
export class HeadermenusComponent implements OnInit {

  constructor() { }
  ngOnInit() {
    
  }
}
